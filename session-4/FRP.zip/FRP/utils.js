const getRandomNumberBetween = (low, high) => {
    return Math.floor((Math.random() * high) + low);
}